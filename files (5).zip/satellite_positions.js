const satellite = require('satellite.js');

// TLE Data for Mwembeshi Satellite
const tleLine1 = "1 25544U 98067A   21275.49138889  .00002182  00000-0  39622-4 0  9993";
const tleLine2 = "2 25544  51.6434  21.0820 0003759  53.3134  73.3033 15.48949473282858";

const mwembeshiSatRec = satellite.twoline2satrec(tleLine1, tleLine2);
const positionAndVelocity = satellite.propagate(mwembeshiSatRec, new Date());
const positionEci = positionAndVelocity.position;

const gmst = satellite.gstime(new Date());
const positionGd = satellite.eciToGeodetic(positionEci, gmst);

const longitude = satellite.degreesLong(positionGd.longitude);
const latitude = satellite.degreesLat(positionGd.latitude);
const altitude = positionGd.height;