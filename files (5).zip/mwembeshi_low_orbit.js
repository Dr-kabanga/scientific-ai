const viewer = new Cesium.Viewer('cesiumContainer', {
  imageryProvider: Cesium.createTileMapServiceImageryProvider({
    url: Cesium.buildModuleUrl('Assets/Textures/NaturalEarthII')
  }),
  baseLayerPicker: false
});

// Mwembeshi Satellite
const mwembeshiSatellite = viewer.entities.add({
  name: "Mwembeshi Satellite",
  position: Cesium.Cartesian3.fromDegrees(30.0, -15.0, 500000), // Replace with live data
  point: {
    pixelSize: 10,
    color: Cesium.Color.BLUE
  },
  label: {
    text: "Mwembeshi Satellite",
    font: "14pt sans-serif",
    style: Cesium.LabelStyle.FILL_AND_OUTLINE,
    outlineWidth: 2,
    verticalOrigin: Cesium.VerticalOrigin.BOTTOM
  }
});

// Example LEO Satellite
const leoSatellite = viewer.entities.add({
  name: "LEO Satellite 1",
  position: Cesium.Cartesian3.fromDegrees(20.0, -10.0, 400000), // Replace with live data
  point: {
    pixelSize: 10,
    color: Cesium.Color.RED
  },
  label: {
    text: "LEO Satellite 1",
    font: "14pt sans-serif",
    style: Cesium.LabelStyle.FILL_AND_OUTLINE,
    outlineWidth: 2,
    verticalOrigin: Cesium.VerticalOrigin.BOTTOM
  }
});

// Update positions in real-time
setInterval(() => {
  // Update Mwembeshi Satellite
  mwembeshiSatellite.position = Cesium.Cartesian3.fromDegrees(
    liveMwembeshiLongitude, liveMwembeshiLatitude, liveMwembeshiAltitude
  );

  // Update LEO Satellite
  leoSatellite.position = Cesium.Cartesian3.fromDegrees(
    liveLeoLongitude, liveLeoLatitude, liveLeoAltitude
  );
}, 1000);