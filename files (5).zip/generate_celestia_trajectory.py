import os

def generate_celestia_script(object_name, initial_orbit, delta_v_event):
    """
    Generates a Celestia Lua script for simulating an orbit with a delta-v maneuver.
    :param object_name: Name of the spacecraft or object (e.g., "Satellite-1")
    :param initial_orbit: Dictionary with initial orbital parameters (semi-major axis, eccentricity, inclination, etc.)
    :param delta_v_event: Dictionary with delta-v maneuver parameters (time, magnitude, direction)
    :return: None (creates a .celx Lua script)
    """
    script_content = f"""
-- Celestia Lua Script for {object_name} Orbit Simulation
require("celestia")

local object = celestia:find("{object_name}")
if not object then
    print("{object_name} not found!")
    return
end

-- Initial Orbit Parameters
object:setOrbit {{
    SemiMajorAxis = {initial_orbit['semi_major_axis']}, -- km
    Eccentricity = {initial_orbit['eccentricity']},
    Inclination = {initial_orbit['inclination']},      -- degrees
    LongitudeOfAscendingNode = {initial_orbit['longitude_of_ascending_node']}, -- degrees
    ArgumentOfPeriapsis = {initial_orbit['argument_of_periapsis']},            -- degrees
    MeanAnomalyAtEpoch = {initial_orbit['mean_anomaly']},                      -- degrees
    Epoch = {initial_orbit['epoch']}                                          -- Julian date
}}

-- Delta-V Event
celestia:addEvent {{
    time = {delta_v_event['time']},      -- Julian date
    deltaV = {{
        magnitude = {delta_v_event['magnitude']}, -- km/s
        direction = {{
            x = {delta_v_event['direction']['x']},
            y = {delta_v_event['direction']['y']},
            z = {delta_v_event['direction']['z']}
        }}
    }}
}}

-- Visualization
celestia:setView {{
    target = "{object_name}",
    track = true
}}
    """
    # Write the script to a file
    script_filename = f"{object_name}_orbit_simulation.celx"
    with open(script_filename, "w") as script_file:
        script_file.write(script_content)

    print(f"Celestia Lua script created: {script_filename}")


# Example Usage
if __name__ == "__main__":
    object_name = "Satellite-1"
    initial_orbit = {
        "semi_major_axis": 42164,  # Geostationary orbit in km
        "eccentricity": 0.0,
        "inclination": 0.0,  # Geostationary orbit
        "longitude_of_ascending_node": 0.0,
        "argument_of_periapsis": 0.0,
        "mean_anomaly": 0.0,
        "epoch": 2451545.0  # J2000 epoch
    }

    delta_v_event = {
        "time": 2451545.5,  # Julian date for delta-v event
        "magnitude": 0.5,  # km/s
        "direction": {
            "x": 1.0,
            "y": 0.0,
            "z": 0.0
        }
    }

    generate_celestia_script(object_name, initial_orbit, delta_v_event)