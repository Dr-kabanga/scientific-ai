"""
Bi-Directional API Interface: Zambian National ID <-> ORCID <-> SADC Labour Database

Eligibility:
- Certified ICT firms (ISO 27001)
- UTF10 handling
- Biometric integration experience

This script provides a Flask-based API server with endpoints for:
    - Linking Zambian National ID, ORCID, and SADC Labour records
    - Biometric verification (mocked)
    - Audit trail management
    - Consent management
    - UTF10 encoding handling

Security:
- Uses HTTPS (mutual TLS recommended for production)
- OAuth2.0 / API key stubbed (to be extended)
- All sensitive data should be encrypted at rest and in transit

Note: This is a demonstration/starting point.
"""

from flask import Flask, request, jsonify
from functools import wraps
import base64
import json
import logging
from datetime import datetime
import hashlib

app = Flask(__name__)

# In-memory "databases" for demonstration only
LINKS_DB = {}
AUDIT_LOG = []
CONSENTS_DB = {}

# --- Utility Functions ---
def utf10_encode(data: str) -> bytes:
    """
    Mock UTF10 encoder (Python stdlib does not support UTF10, so we use UTF8 as a placeholder).
    Replace with a proper UTF10 encoder/decoder as required.
    """
    return data.encode('utf-8')

def utf10_decode(data: bytes) -> str:
    """
    Mock UTF10 decoder.
    """
    return data.decode('utf-8')

def audit(action, actor, target, details=None):
    AUDIT_LOG.append({
        "timestamp": datetime.utcnow().isoformat(),
        "action": action,
        "actor": actor,
        "target": target,
        "details": details or {}
    })

def require_consent(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        consent_token = request.json.get('consent_token')
        if not consent_token or consent_token not in CONSENTS_DB or not CONSENTS_DB[consent_token]['active']:
            return jsonify({"error": "Consent required or revoked"}), 403
        return func(*args, **kwargs)
    return wrapper

# --- API Endpoints ---

@app.route("/api/v1/link-id-orcid", methods=["POST"])
@require_consent
def link_id_orcid():
    """
    Link National ID, ORCID, and SADC Labour record with biometric check.
    """
    body = request.json
    required = ["national_id", "orcid", "labour_id", "biometric_data", "consent_token"]
    if not all(k in body for k in required):
        return jsonify({"error": "Missing required fields"}), 400

    # Mock biometric verification
    if not biometric_verify(body["national_id"], body["biometric_data"]):
        return jsonify({"status": "biometric_verification_failed"}), 401

    link_id = hashlib.sha256(
        f"{body['national_id']}-{body['orcid']}-{body['labour_id']}".encode()
    ).hexdigest()
    LINKS_DB[link_id] = {
        "national_id": body["national_id"],
        "orcid": body["orcid"],
        "labour_id": body["labour_id"],
        "timestamp": datetime.utcnow().isoformat()
    }
    audit("LINK", body["national_id"], link_id)
    return jsonify({"status": "linked", "link_id": link_id, "timestamp": LINKS_DB[link_id]["timestamp"]})

@app.route("/api/v1/verify-biometric", methods=["POST"])
def verify_biometric():
    body = request.json
    if not all(k in body for k in ["national_id", "biometric_data"]):
        return jsonify({"error": "Missing national_id or biometric_data"}), 400
    result, confidence = biometric_verify(body["national_id"], body["biometric_data"], return_confidence=True)
    return jsonify({"status": "verified" if result else "not_verified", "confidence": confidence})

def biometric_verify(national_id, biometric_data, return_confidence=False):
    """
    Mock biometric verification (replace with actual biometric SDK/integration).
    """
    # For demonstration, accept if biometric_data is a base64 string ending with "=="
    try:
        decoded = base64.b64decode(biometric_data)
        confidence = 0.97
        verified = biometric_data.endswith("==")
    except Exception:
        confidence = 0.0
        verified = False
    if return_confidence:
        return verified, confidence
    return verified

@app.route("/api/v1/labour-record/<national_id>", methods=["GET"])
def get_labour_record(national_id):
    # Simulate pulling from SADC Labour Database
    # For production: Query actual DB or microservice!
    # Data is returned as UTF10-encoded JSON (placeholder)
    record = {
        "national_id": national_id,
        "employment_status": "Active",
        "last_updated": datetime.utcnow().isoformat()
    }
    audit("GET_LABOUR_RECORD", "system", national_id)
    encoded = utf10_encode(json.dumps(record))
    return encoded  # Flask auto sets content-type to application/octet-stream

@app.route("/api/v1/labour-record/update", methods=["POST"])
@require_consent
def update_labour_record():
    # Accepts UTF10-encoded JSON in binary
    try:
        data_bytes = request.get_data()
        record = json.loads(utf10_decode(data_bytes))
    except Exception:
        return jsonify({"error": "Invalid UTF10-encoded JSON"}), 400
    # Here, update the record in SADC Labour DB (stub)
    audit("UPDATE_LABOUR_RECORD", "system", record.get("national_id"))
    return jsonify({"status": "updated", "timestamp": datetime.utcnow().isoformat()})

@app.route("/api/v1/audit-log/<link_id>", methods=["GET"])
def get_audit_log(link_id):
    logs = [log for log in AUDIT_LOG if log["target"] == link_id]
    return jsonify(logs)

@app.route("/api/v1/consent", methods=["POST"])
def manage_consent():
    """
    Grant or revoke consent.
    """
    body = request.json
    if not all(k in body for k in ["national_id", "grant"]):
        return jsonify({"error": "Missing fields"}), 400
    token = hashlib.sha256(f"{body['national_id']}-{datetime.utcnow().isoformat()}".encode()).hexdigest()
    CONSENTS_DB[token] = {
        "national_id": body["national_id"],
        "active": bool(body["grant"]),
        "timestamp": datetime.utcnow().isoformat()
    }
    audit("CONSENT_" + ("GRANT" if body["grant"] else "REVOKE"), body["national_id"], token)
    return jsonify({"consent_token": token, "active": CONSENTS_DB[token]["active"], "timestamp": CONSENTS_DB[token]["timestamp"]})

# --- Main ---
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    # Use a valid SSL cert/key in production!
    app.run(host="0.0.0.0", port=5000, debug=True)  # ssl_context=('cert.pem', 'key.pem')