# Bi-Directional API Interface Specification
## Purpose
Enable secure, real-time, bi-directional data exchange between:
- Zambian National ID System
- ORCID (Open Researcher and Contributor ID)
- SADC Labour Database

## Eligibility Requirements
- Only Certified ICT firms (ISO 27001-compliant)
- Proven UTF10 encoding/decoding experience
- Prior biometric system integration (e.g., fingerprint, iris, facial recognition)
- Secure hosting and data handling

## Functional Overview
1. **Identity Linking**: Link Zambian National ID to an ORCID and SADC Labour record.
2. **Bi-Directional Sync**: Changes in any system (ID, ORCID, Labour) propagate to others.
3. **Biometric Verification**: Support for biometric validation during linking.
4. **Audit & Consent**: Track data access/modification, with user consent logging.

## API Architecture
- **RESTful JSON APIs** (with UTF10 encoding support)
- **OAuth2.0** (with SAML/JWT support for federated identity)
- **Mutual TLS (mTLS)**
- **OpenAPI 3.0 Specification**
- **Webhooks** for event-driven updates

## Core API Endpoints

### 1. Identity Linkage
`POST /api/v1/link-id-orcid`
- Request:  
  ```json
  {
    "national_id": "string",
    "orcid": "string",
    "labour_id": "string",
    "biometric_data": "base64string",
    "consent_token": "string"
  }
  ```
- Response:  
  ```json
  {
    "status": "linked",
    "link_id": "string",
    "timestamp": "ISO8601"
  }
  ```

### 2. Biometric Verification
`POST /api/v1/verify-biometric`
- Request:  
  ```json
  {
    "national_id": "string",
    "biometric_data": "base64string"
  }
  ```
- Response:  
  ```json
  {
    "status": "verified | not_verified",
    "confidence": "float"
  }
  ```

### 3. Data Sync (Push/Pull)
`GET /api/v1/labour-record/{national_id}`
`POST /api/v1/labour-record/update`
- Request/Response: Labour record in standardized JSON, UTF10 encoded.

### 4. Audit Trail
`GET /api/v1/audit-log/{link_id}`
- Returns all access/modification events with timestamp, actor, and action.

### 5. Consent Management
`POST /api/v1/consent`
- User can grant/revoke data sharing consent.

## Security Considerations
- **ISO 27001 controls**: Data encryption at rest & in transit, access controls, audit logging.
- **Biometric Data**: Always transmitted as encrypted payload, never stored in raw format.
- **UTF10 Encoding**: All endpoints accept and return UTF10-encoded strings.
- **Rate Limiting & Monitoring**: To prevent abuse.

## Deployment & Integration
- **Sandbox Environment** for testing.
- **Production endpoints** only available to certified, whitelisted IPs.
- **Webhooks**: For real-time update notifications between systems.

## Example Sequence: Linking a National ID and ORCID
1. User authenticates with National ID (with biometric verification).
2. User provides ORCID and consents to linkage.
3. API verifies biometric, creates a link, updates SADC Labour DB.
4. All changes are logged; user can revoke consent at any time.

## Documentation
- Full OpenAPI 3.0 spec to be provided.
- Security clearance (ISO 27001) verification is mandatory for API key issuance.
- Code samples in Python, Java, and C#.

## Contact & Support
- Technical queries: [support@sadc-labour.org](mailto:support@sadc-labour.org)
- Onboarding: [onboarding@sadc-labour.org](mailto:onboarding@sadc-labour.org)

---

**Note:** This spec assumes access to national ID and ORCID systems through secure, government-approved channels. All biometric integration must comply with local privacy laws and best practices.