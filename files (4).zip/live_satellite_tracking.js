const viewer = new Cesium.Viewer('cesiumContainer', {
  imageryProvider: Cesium.createTileMapServiceImageryProvider({
    url : Cesium.buildModuleUrl('Assets/Textures/NaturalEarthII')
  }),
  baseLayerPicker: false
});

// Add live satellite data
const chambeshiSatellite = viewer.entities.add({
  name: "Chambeshi Satellite",
  position: Cesium.Cartesian3.fromDegrees(longitude, latitude, altitude), // Replace with live values
  model: {
    uri: 'path-to-satellite-model.gltf', // Optional: 3D satellite model
    scale: 1.0
  },
  label: {
    text: "Chambeshi Satellite",
    font: "14pt sans-serif",
    style: Cesium.LabelStyle.FILL_AND_OUTLINE,
    outlineWidth: 2,
    verticalOrigin: Cesium.VerticalOrigin.BOTTOM
  }
});

// Update position in real-time
setInterval(() => {
  chambeshiSatellite.position = Cesium.Cartesian3.fromDegrees(liveLongitude, liveLatitude, liveAltitude); // Replace with live telemetry
}, 1000);