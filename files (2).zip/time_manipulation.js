// Interactive Time Manipulation
let timeMultiplier = 1; // Default time flow

// Event listeners for time control
document.addEventListener("keydown", (event) => {
    if (event.key === "ArrowUp") {
        timeMultiplier = Math.min(timeMultiplier + 0.1, 3); // Fast forward up to 3x speed
    } else if (event.key === "ArrowDown") {
        timeMultiplier = Math.max(timeMultiplier - 0.1, 0.1); // Slow down to 0.1x speed
    } else if (event.key === "Space") {
        timeMultiplier = timeMultiplier === 0 ? 1 : 0; // Pause/Resume
    }
});

// Update objects with time manipulation
function animateWithTimeManipulation() {
    const delta = clock.getDelta() * timeMultiplier;

    // Example: Rotate Chrono-Key based on timeMultiplier
    if (chronoKey) {
        chronoKey.rotation.y += delta;
    }
}