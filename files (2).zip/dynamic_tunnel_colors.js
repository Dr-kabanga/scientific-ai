// Tunnel Colors for Dimensions
const dimensionColors = [
    0x001133, // Dimension 1
    0x113300, // Dimension 2
    0x330011, // Dimension 3
];

// Update Tunnel Color
function updateTunnelColor(dimensionIndex) {
    scene.background = new THREE.Color(dimensionColors[dimensionIndex]);
}

// Call this function when switching dimensions
function switchDimension(index) {
    currentDimensionIndex = index;
    updateTunnelColor(index);
    playSoundEffect();
    playParticleEffect();
}