const audioLoader = new THREE.AudioLoader();
const listener = new THREE.AudioListener();
camera.add(listener);

const sound = new THREE.Audio(listener);
audioLoader.load('path/to/sound_effect.mp3', (buffer) => {
    sound.setBuffer(buffer);
    sound.setLoop(false);
    sound.setVolume(0.5);
});

// Play sound effect
function playSoundEffect() {
    sound.play();
}