// Multi-Dimensional Navigation (AI-Fusion Tunnels)
const dimensions = [
    { name: "Dimension 1", color: 0x001133 },
    { name: "Dimension 2", color: 0x113300 },
    { name: "Dimension 3", color: 0x330011 }
];
let currentDimensionIndex = 0;

// Function to switch dimensions
function switchDimension(index) {
    if (index < 0 || index >= dimensions.length) return;
    currentDimensionIndex = index;

    // Transition effect
    const transitionDuration = 1000; // 1 second
    let startTime = null;

    function transition(timestamp) {
        if (!startTime) startTime = timestamp;
        const elapsed = timestamp - startTime;

        const progress = Math.min(elapsed / transitionDuration, 1);
        scene.background = new THREE.Color(dimensions[currentDimensionIndex].color).lerp(
            new THREE.Color(dimensions[(currentDimensionIndex + 1) % dimensions.length].color),
            progress
        );

        if (progress < 1) {
            requestAnimationFrame(transition);
        }
    }

    requestAnimationFrame(transition);
}

// Event listener for navigation
document.addEventListener("keydown", (event) => {
    if (event.key === "ArrowRight") {
        switchDimension((currentDimensionIndex + 1) % dimensions.length);
    } else if (event.key === "ArrowLeft") {
        switchDimension((currentDimensionIndex - 1 + dimensions.length) % dimensions.length);
    }
});