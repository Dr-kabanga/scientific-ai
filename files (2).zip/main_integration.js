function switchDimension(index) {
    currentDimensionIndex = index;

    // Update Tunnel Color
    updateTunnelColor(index);

    // Play Effects
    playSoundEffect();
    playParticleEffect();
}