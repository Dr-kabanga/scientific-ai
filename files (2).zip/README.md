# Movie Studio 2025 Platinum Engine MVP

## Overview
This project demonstrates the **Movie Studio 2025 Platinum Engine** MVP. It features:
- A rotating Chrono-Key (golden sphere) in a cosmic-themed 3D scene.
- Basic lighting and camera controls.
- A responsive experience with Three.js.

## Features
1. **Scene Rendering**
   - A 3D environment with cosmic tones.
   - A glowing Chrono-Key object.

2. **Animation**
   - The Chrono-Key rotates to simulate time flow.

3. **Responsiveness**
   - The scene adjusts to the browser window size.

## How to Run
1. Install dependencies:
   ```bash
   npm install