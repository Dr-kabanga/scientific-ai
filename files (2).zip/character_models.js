// Loaders for Hero and Being of Light character models
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';

const loader = new GLTFLoader();
const characterModels = {};

// Load Hero Model
loader.load('path/to/hero_model.glb', (gltf) => {
    characterModels.hero = gltf.scene;
    characterModels.hero.position.set(0, 0, 0); // Set initial position
    scene.add(characterModels.hero);
});

// Load Being of Light Model
loader.load('path/to/being_of_light_model.glb', (gltf) => {
    characterModels.beingOfLight = gltf.scene;
    characterModels.beingOfLight.position.set(2, 0, 0); // Set initial position
    scene.add(characterModels.beingOfLight);
});

// Animate characters
function animateCharacters() {
    if (characterModels.hero) {
        characterModels.hero.rotation.y += 0.01; // Rotate Hero
    }
    if (characterModels.beingOfLight) {
        characterModels.beingOfLight.rotation.y -= 0.01; // Rotate Being of Light
    }
}