// Particle System for Dimension Switching
const particleCount = 1000;
const particles = new THREE.BufferGeometry();
const particlePositions = new Float32Array(particleCount * 3);

for (let i = 0; i < particleCount; i++) {
    particlePositions[i * 3] = Math.random() * 10 - 5; // X
    particlePositions[i * 3 + 1] = Math.random() * 10 - 5; // Y
    particlePositions[i * 3 + 2] = Math.random() * 10 - 5; // Z
}

particles.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));

const particleMaterial = new THREE.PointsMaterial({
    color: 0xffffff,
    size: 0.05,
});

const particleSystem = new THREE.Points(particles, particleMaterial);
scene.add(particleSystem);

// Animate particles during dimension switching
function animateParticles() {
    particleSystem.rotation.y += 0.01;
}

// Call this function during transitions
function playParticleEffect() {
    particleSystem.visible = true;
    setTimeout(() => {
        particleSystem.visible = false;
    }, 2000); // Effect lasts for 2 seconds
}