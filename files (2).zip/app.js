// Select DOM elements
const taskInput = document.getElementById("taskInput");
const addTaskButton = document.getElementById("addTaskButton");
const taskList = document.getElementById("taskList");

// Load tasks from local storage
document.addEventListener("DOMContentLoaded", loadTasks);

// Add task event listener
addTaskButton.addEventListener("click", addTask);

// Add task to the list
function addTask() {
    const taskText = taskInput.value.trim();
    if (taskText === "") return alert("Please enter a task!");

    const task = createTaskElement(taskText);
    taskList.appendChild(task);

    saveTaskToLocalStorage(taskText);
    taskInput.value = "";
}

// Create a task element
function createTaskElement(taskText) {
    const li = document.createElement("li");
    li.className = "task-item";

    const taskContent = document.createElement("span");
    taskContent.textContent = taskText;

    const deleteButton = document.createElement("button");
    deleteButton.textContent = "Delete";
    deleteButton.className = "delete-btn";
    deleteButton.addEventListener("click", () => {
        li.remove();
        removeTaskFromLocalStorage(taskText);
    });

    li.appendChild(taskContent);
    li.appendChild(deleteButton);
    return li;
}

// Save task to local storage
function saveTaskToLocalStorage(task) {
    let tasks = getTasksFromLocalStorage();
    tasks.push(task);
    localStorage.setItem("tasks", JSON.stringify(tasks));
}

// Remove task from local storage
function removeTaskFromLocalStorage(taskToRemove) {
    let tasks = getTasksFromLocalStorage();
    tasks = tasks.filter(task => task !== taskToRemove);
    localStorage.setItem("tasks", JSON.stringify(tasks));
}

// Get tasks from local storage
function getTasksFromLocalStorage() {
    const tasks = localStorage.getItem("tasks");
    return tasks ? JSON.parse(tasks) : [];
}

// Load tasks when the page loads
function loadTasks() {
    const tasks = getTasksFromLocalStorage();
    tasks.forEach(taskText => {
        const task = createTaskElement(taskText);
        taskList.appendChild(task);
    });
}