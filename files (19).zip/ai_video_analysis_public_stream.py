import cv2
import torch

# Load YOLOv5 model - downloads weights if not present
model = torch.hub.load('ultralytics/yolov5', 'yolov5s', pretrained=True)

# Use a public video stream or file (e.g., traffic cam, YouTube stream, or local file)
# For demo, use a sample video file. Replace with your public video URL if desired.
VIDEO_SOURCE = "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4"

cap = cv2.VideoCapture(VIDEO_SOURCE)

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    # YOLO expects RGB images
    results = model(frame[..., ::-1])

    # Render results on the frame
    annotated_frame = results.render()[0][..., ::-1]  # Convert back to BGR for OpenCV

    # Display the frame
    cv2.imshow('Public Video AI Analysis (YOLOv5)', annotated_frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()