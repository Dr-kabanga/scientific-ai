from skyfield.api import load, EarthSatellite
import matplotlib.pyplot as plt

# Orbital parameters for W33-A (example satellite)
tle_line1 = '1 25544U 98067A   23098.78745787  .00016717  00000+0  10270-3 0  9009'
tle_line2 = '2 25544  51.6421  21.1283 0008849  45.7056 314.3487 15.50003483222611'

# Load the satellite and timescale
satellite = EarthSatellite(tle_line1, tle_line2, 'W33-A', load.timescale())
ts = load.timescale()
t = ts.now()

# Calculate satellite position
geocentric = satellite.at(t)
subpoint = geocentric.subpoint()

# Print satellite details
print(f"Satellite Name: {satellite.name}")
print(f"Latitude: {subpoint.latitude.degrees:.2f}°")
print(f"Longitude: {subpoint.longitude.degrees:.2f}°")
print(f"Altitude: {subpoint.elevation.km:.2f} km")

# Plot satellite ground track
def plot_ground_track(satellite, duration_minutes=90, timestep=1):
    t0 = ts.now()
    times = ts.utc(t0.utc_datetime() + np.arange(0, duration_minutes, timestep) / 1440.0)

    latitudes, longitudes = [], []
    for time in times:
        subpoint = satellite.at(time).subpoint()
        latitudes.append(subpoint.latitude.degrees)
        longitudes.append(subpoint.longitude.degrees)

    plt.figure(figsize=(10, 6))
    plt.plot(longitudes, latitudes, label=satellite.name)
    plt.title("Satellite Ground Track")
    plt.xlabel("Longitude (°)")
    plt.ylabel("Latitude (°)")
    plt.legend()
    plt.grid()
    plt.show()

plot_ground_track(satellite)