const express = require('express');
const cors = require('cors');
const app = express();
const port = 3000;

// Use middleware for JSON parsing and CORS
app.use(express.json());
app.use(cors());

// Mock Data for Annual Income
const incomeData = [
  { Source: 'ZAFA Supervisor', Amount: 360000 * 12 },
  { Source: 'Ministry of Health', Amount: 56000 * 12 },
  { Source: 'Gratuity', Amount: 150000 },
  { Source: 'Project Leadership (2x)', Amount: 2 * 120000 },
  { Source: 'Other Income', Amount: 123000 },
];

// Generate Monthly Projection Data Dynamically
const generateMonthlyProjection = () => {
  const monthlyProjection = Array.from({ length: 12 }, (_, i) => ({
    Month: new Date(2025, i).toLocaleString('default', { month: 'long' }),
    ZAFA: 360000,
    Health: 56000,
    Other: i === 1 ? 5000 : i === 2 ? 15500 : 0, // Example values for Feb and Mar
  }));

  monthlyProjection.forEach(d => {
    d.Total = d.ZAFA + d.Health + d.Other;
  });

  return monthlyProjection;
};

// API Endpoints

// Endpoint for Annual Income Data
app.get('/api/incomeData', (req, res) => {
  res.json(incomeData);
});

// Endpoint for Monthly Projection Data
app.get('/api/monthlyProjection', (req, res) => {
  const monthlyProjection = generateMonthlyProjection();
  res.json(monthlyProjection);
});

// Start the Server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});