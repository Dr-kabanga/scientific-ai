import React, { useEffect, useState } from 'react';
import axios from 'axios'; // For API calls
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  ResponsiveContainer,
} from 'recharts';
import { Card, CardContent } from '@/components/ui/card';

export default function IncomeForecastDashboard() {
  const [incomeData, setIncomeData] = useState([]);
  const [monthlyProjection, setMonthlyProjection] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        // Fetch annual income data
        const incomeResponse = await axios.get('/api/incomeData');
        // Fetch monthly projection data
        const monthlyResponse = await axios.get('/api/monthlyProjection');
        setIncomeData(incomeResponse.data);
        setMonthlyProjection(monthlyResponse.data);
      } catch (err) {
        setError('Failed to load data. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return <div className="text-center p-6">Loading...</div>;
  }

  if (error) {
    return <div className="text-center p-6 text-red-500">{error}</div>;
  }

  return (
    <div className="p-6 space-y-8">
      <h1 className="text-3xl font-bold text-center">Projected Annual Income Overview</h1>

      {/* Annual Income by Source */}
      <Card>
        <CardContent>
          <h2 className="text-xl font-semibold mb-4">Annual Income by Source</h2>
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={incomeData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="Source" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="Amount" fill="#8884d8" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Monthly Income Forecast */}
      <Card>
        <CardContent>
          <h2 className="text-xl font-semibold mb-4">Monthly Income Forecast (2025)</h2>
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={monthlyProjection}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis
                dataKey="Month"
                angle={-45}
                textAnchor="end"
                height={60}
                interval={0}
              />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line
                type="monotone"
                dataKey="ZAFA"
                stroke="#82ca9d"
                name="ZAFA Salary"
              />
              <Line
                type="monotone"
                dataKey="Health"
                stroke="#8884d8"
                name="Health Ministry"
              />
              <Line
                type="monotone"
                dataKey="Other"
                stroke="#ffc658"
                name="Other Income"
              />
              <Line
                type="monotone"
                dataKey="Total"
                stroke="#ff7300"
                name="Total Monthly Income"
                strokeWidth={3}
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}