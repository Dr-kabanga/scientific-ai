import cv2
import numpy as np
from tqdm import tqdm

class AIVideoEditor:
    def __init__(self, video_path):
        """
        Initialize the AI Video Editor with the input video file.
        """
        self.video_path = video_path
        self.frames = []
        self.fps = 30
        self._load_frames()

    def _load_frames(self):
        """
        Load video frames into memory for processing.
        """
        cap = cv2.VideoCapture(self.video_path)
        self.fps = cap.get(cv2.CAP_PROP_FPS) or 30
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        pbar = tqdm(total=total_frames, desc="Loading frames")
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
            self.frames.append(frame)
            pbar.update(1)
        cap.release()
        pbar.close()
        print(f"Loaded {len(self.frames)} frames from video.")

    def scene_detection(self, threshold=30):
        """
        Perform scene detection by comparing frames.
        """
        print("\nPerforming Scene Detection...")
        scene_changes = []
        prev_frame = None
        for i, frame in enumerate(self.frames):
            if prev_frame is None:
                prev_frame = frame
                continue
            diff = cv2.absdiff(cv2.cvtColor(prev_frame, cv2.COLOR_BGR2GRAY),
                               cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY))
            if np.mean(diff) > threshold:
                scene_changes.append(i)
            prev_frame = frame
        print(f"Detected {len(scene_changes)} scene changes.")
        return scene_changes

    def add_effect(self, effect_type="grayscale"):
        """
        Add an effect to the video, such as grayscale or sepia.
        """
        print(f"\nApplying {effect_type} effect...")
        for i, frame in enumerate(self.frames):
            if effect_type == "grayscale":
                self.frames[i] = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            elif effect_type == "sepia":
                kernel = np.array([[0.272, 0.534, 0.131],
                                   [0.349, 0.686, 0.168],
                                   [0.393, 0.769, 0.189]])
                self.frames[i] = cv2.transform(frame, kernel)
            # Add more effects as needed

    def render_video(self, output_path, fps=None, output_format="mp4"):
        """
        Render the edited video to a specified output file.
        Supports MP4, AVI, and frame sequence output.
        """
        print(f"\nRendering video to {output_path}...")
        if not self.frames:
            raise ValueError("No frames loaded")
        fps = fps or self.fps
        height, width = (self.frames[0].shape[:2] if len(self.frames[0].shape) == 3
                         else (self.frames[0].shape[0], self.frames[0].shape[1]))
        fourcc = cv2.VideoWriter_fourcc(*('mp4v' if output_format == "mp4" else 'XVID'))
        out = cv2.VideoWriter(output_path, fourcc, fps, (width, height),
                              isColor=(len(self.frames[0].shape) == 3))
        for frame in tqdm(self.frames, desc="Rendering video"):
            out.write(frame if len(frame.shape) == 3 else cv2.cvtColor(frame, cv2.COLOR_GRAY2BGR))
        out.release()
        print("Rendering completed.")

    def save_frames(self, output_dir):
        """
        Save video frames as a sequence of images.
        """
        import os
        os.makedirs(output_dir, exist_ok=True)
        for idx, frame in enumerate(tqdm(self.frames, desc="Saving frames")):
            cv2.imwrite(os.path.join(output_dir, f"frame_{idx:04d}.png"), frame)
        print(f"Frames saved to {output_dir}")
