import os
from scientific_ai.video.editing import AIVideoEditor

def test_scene_detection():
    # Provide a sample video path for local/unit test
    video_path = "tests/sample.mp4"
    if not os.path.exists(video_path):
        print("Sample video not found; skipping test.")
        return
    editor = AIVideoEditor(video_path)
    scenes = editor.scene_detection()
    assert isinstance(scenes, list)

def test_render_and_save_frames(tmp_path):
    video_path = "tests/sample.mp4"
    if not os.path.exists(video_path):
        print("Sample video not found; skipping test.")
        return
    editor = AIVideoEditor(video_path)
    editor.add_effect("grayscale")
    out_video = tmp_path / "out.mp4"
    editor.render_video(str(out_video))
    assert out_video.exists()
    frames_dir = tmp_path / "frames"
    editor.save_frames(str(frames_dir))
    assert frames_dir.exists()