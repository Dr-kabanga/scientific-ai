from fastapi import APIRouter, HTTPException
from sqlalchemy.orm import Session
from app.models.workforce import Workforce
from app.schemas import WorkforceCreate, WorkforceResponse
from app.database import get_db
from typing import List

router = APIRouter(
    prefix="/workforce",
    tags=["Workforce"],
    responses={404: {"description": "Not found"}},
)

@router.get("/", response_model=List[WorkforceResponse])
def get_workforce_data(db: Session = get_db()):
    return db.query(Workforce).all()

@router.post("/", response_model=WorkforceResponse)
def add_workforce_entry(workforce: WorkforceCreate, db: Session = get_db()):
    new_entry = Workforce(**workforce.dict())
    db.add(new_entry)
    db.commit()
    db.refresh(new_entry)
    return new_entry