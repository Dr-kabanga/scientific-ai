from pydantic import BaseModel
from datetime import datetime

class WorkforceBase(BaseModel):
    nrc: str
    name: str
    employer: str
    zra_income_sources: int
    last_worklog_submitted: datetime
    productivity_index: float
    circular_compliance_score: float

class WorkforceCreate(WorkforceBase):
    pass

class WorkforceResponse(WorkforceBase):
    id: int

    class Config:
        orm_mode = True