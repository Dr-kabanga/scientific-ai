from sqlalchemy import Column, String, Integer, DateTime, Float
from app.database import Base

class Workforce(Base):
    __tablename__ = "workforce"

    id = Column(Integer, primary_key=True, index=True)
    nrc = Column(String, unique=True, index=True)
    name = Column(String, index=True)
    employer = Column(String, index=True)
    zra_income_sources = Column(Integer)
    last_worklog_submitted = Column(DateTime)
    productivity_index = Column(Float)
    circular_compliance_score = Column(Float)