from fastapi import FastAPI
from app.api import workforce
from app.database import engine, Base

# Initialize FastAPI app
app = FastAPI(
    title="ZRA Workforce Monitoring System",
    description="API for monitoring workforce productivity and compliance",
    version="1.0.0",
)

# Create database tables
Base.metadata.create_all(bind=engine)

# Include API routers
app.include_router(workforce.router)

@app.get("/")
def root():
    return {"message": "Welcome to the ZRA Workforce Monitoring System API"}