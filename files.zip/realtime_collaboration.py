import firebase_admin
from firebase_admin import credentials, db
import threading

# Initialize Firebase
cred = credentials.Certificate("path/to/your-firebase-credentials.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://your-database-name.firebaseio.com/'
})

# Function to listen for real-time updates
def listen_to_script_changes(script_id):
    def listener(event):
        print(f"Change detected: {event.data}")

    ref = db.reference(f"scripts/{script_id}")
    ref.listen(listener)

# Function to update a script
def update_script(script_id, new_content):
    ref = db.reference(f"scripts/{script_id}")
    ref.update({"content": new_content})
    print(f"Script {script_id} updated.")

# Function to retrieve a script
def retrieve_script(script_id):
    ref = db.reference(f"scripts/{script_id}")
    return ref.get()

# Real-time collaboration example
if __name__ == "__main__":
    script_id = "collaborative_script"
    
    # Start listening for changes in a separate thread
    threading.Thread(target=listen_to_script_changes, args=(script_id,), daemon=True).start()

    # Simulate updating the script
    while True:
        user_input = input("Enter new script content (or 'exit' to quit): ")
        if user_input.lower() == "exit":
            break
        update_script(script_id, user_input)